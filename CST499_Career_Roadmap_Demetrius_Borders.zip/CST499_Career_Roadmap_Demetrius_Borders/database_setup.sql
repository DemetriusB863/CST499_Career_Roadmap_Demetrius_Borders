-- ============================================================
-- Online Course Registration System — Database Setup
-- Run this in phpMyAdmin > SQL tab, or via MySQL CLI
-- ============================================================

-- 1. Create the database
CREATE DATABASE IF NOT EXISTS course_db
  CHARACTER SET utf8
  COLLATE utf8_general_ci;

USE course_db;

-- 2. Users table (stores registered student accounts)
CREATE TABLE IF NOT EXISTS users (
    user_id        INT           NOT NULL AUTO_INCREMENT,
    first_name     VARCHAR(50)   NOT NULL,
    last_name      VARCHAR(50)   NOT NULL,
    email          VARCHAR(100)  NOT NULL UNIQUE,
    password_hash  VARCHAR(255)  NOT NULL,
    student_id     VARCHAR(20)   NOT NULL UNIQUE,
    created_at     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id)
);

-- 3. Courses table (available courses per semester)
CREATE TABLE IF NOT EXISTS courses (
    course_id      INT           NOT NULL AUTO_INCREMENT,
    course_name    VARCHAR(100)  NOT NULL,
    course_code    VARCHAR(20)   NOT NULL UNIQUE,
    instructor     VARCHAR(100)  NOT NULL,
    semester       ENUM('Spring','Summer','Fall') NOT NULL,
    year           YEAR          NOT NULL,
    capacity       INT           NOT NULL DEFAULT 30,
    enrolled_count INT           NOT NULL DEFAULT 0,
    PRIMARY KEY (course_id)
);

-- 4. Enrollments table (links students to courses they are enrolled in)
CREATE TABLE IF NOT EXISTS enrollments (
    enrollment_id  INT       NOT NULL AUTO_INCREMENT,
    user_id        INT       NOT NULL,
    course_id      INT       NOT NULL,
    enrolled_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (enrollment_id),
    UNIQUE KEY uq_enrollment (user_id, course_id),
    FOREIGN KEY (user_id)   REFERENCES users(user_id)   ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE
);

-- 5. Waitlist table (students waiting for a full course)
CREATE TABLE IF NOT EXISTS waitlist (
    waitlist_id    INT       NOT NULL AUTO_INCREMENT,
    user_id        INT       NOT NULL,
    course_id      INT       NOT NULL,
    position       INT       NOT NULL,
    added_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (waitlist_id),
    UNIQUE KEY uq_waitlist (user_id, course_id),
    FOREIGN KEY (user_id)   REFERENCES users(user_id)   ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE
);

-- ============================================================
-- Sample course data (optional — for testing)
-- ============================================================
INSERT INTO courses (course_name, course_code, instructor, semester, year, capacity) VALUES
  ('Introduction to Programming',  'CST101', 'Dr. Smith',    'Fall',   2026, 30),
  ('Web Development Fundamentals', 'CST201', 'Prof. Garcia', 'Fall',   2026, 25),
  ('Database Systems',             'CST310', 'Dr. Johnson',  'Fall',   2026, 28),
  ('Software Engineering Capstone','CST499', 'Prof. Rangitsch', 'Fall', 2026, 20);

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register – Course Registration</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background: #f0f4f8; font-family: 'Segoe UI', sans-serif; min-height: 100vh; display: flex; flex-direction: column; }
    nav { background: #1a3c6e; }
    .card { border: none; border-radius: 12px; box-shadow: 0 4px 24px rgba(0,0,0,.10); }
    .card-header { background: linear-gradient(135deg, #1a3c6e, #2d6fbd); color: white; border-radius: 12px 12px 0 0 !important; text-align: center; padding: 24px; }
    .btn-primary { background: #1a3c6e; border: none; }
    .btn-primary:hover { background: #2d6fbd; }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg mb-4">
  <div class="container">
    <a class="navbar-brand fw-bold text-white" href="index.php">CourseReg</a>
    <div class="ms-auto">
      <a href="login.php"    class="btn btn-outline-light me-2">Login</a>
      <a href="register.php" class="btn btn-light text-primary fw-bold">Register</a>
    </div>
  </div>
</nav>

<div class="container d-flex justify-content-center flex-grow-1">
  <div class="col-md-7 col-lg-6">

    <?php
    session_start();
    $error = "";

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        require_once 'db_connection.php';
        $conn = DBConnection::getConnection();

        // Sanitize inputs
        $first_name = trim(htmlspecialchars($_POST['first_name']));
        $last_name  = trim(htmlspecialchars($_POST['last_name']));
        $email      = trim(htmlspecialchars($_POST['email']));
        $password   = $_POST['password'];
        $confirm    = $_POST['confirm_password'];
        $student_id = trim(htmlspecialchars($_POST['student_id']));

        // Server-side validation
        if (empty($first_name) || empty($last_name) || empty($email) || empty($password) || empty($student_id)) {
            $error = "All fields are required.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Please enter a valid email address.";
        } elseif (strlen($password) < 8) {
            $error = "Password must be at least 8 characters.";
        } elseif ($password !== $confirm) {
            $error = "Passwords do not match.";
        } else {
            // Check email uniqueness
            $chk = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
            $chk->bind_param("s", $email);
            $chk->execute();
            $chk->store_result();
            if ($chk->num_rows > 0) {
                $error = "An account with that email already exists.";
            }
            $chk->close();

            // Check student ID uniqueness
            if (!$error) {
                $chk2 = $conn->prepare("SELECT user_id FROM users WHERE student_id = ?");
                $chk2->bind_param("s", $student_id);
                $chk2->execute();
                $chk2->store_result();
                if ($chk2->num_rows > 0) {
                    $error = "That Student ID is already registered.";
                }
                $chk2->close();
            }

            // Insert new user
            if (!$error) {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $ins  = $conn->prepare(
                    "INSERT INTO users (first_name, last_name, email, password_hash, student_id) VALUES (?, ?, ?, ?, ?)"
                );
                $ins->bind_param("sssss", $first_name, $last_name, $email, $hash, $student_id);
                if ($ins->execute()) {
                    $_SESSION['success'] = "Registration successful! Please sign in.";
                    header("Location: login.php");
                    exit();
                } else {
                    $error = "Registration failed. Please try again.";
                }
                $ins->close();
            }
        }
    }
    ?>

    <?php if ($error): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card">
      <div class="card-header">
        <h4 class="mb-0 fw-bold">Create an Account</h4>
        <small>Join the course registration platform</small>
      </div>
      <div class="card-body p-4">
        <form method="POST" action="register.php">
          <div class="row g-3">
            <div class="col-md-6">
              <label for="first_name" class="form-label fw-semibold">First Name</label>
              <input type="text" class="form-control" id="first_name" name="first_name" required
                     value="<?= isset($_POST['first_name']) ? htmlspecialchars($_POST['first_name']) : '' ?>">
            </div>
            <div class="col-md-6">
              <label for="last_name" class="form-label fw-semibold">Last Name</label>
              <input type="text" class="form-control" id="last_name" name="last_name" required
                     value="<?= isset($_POST['last_name']) ? htmlspecialchars($_POST['last_name']) : '' ?>">
            </div>
            <div class="col-12">
              <label for="email" class="form-label fw-semibold">Email Address</label>
              <input type="email" class="form-control" id="email" name="email" required
                     placeholder="you@example.com"
                     value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>">
            </div>
            <div class="col-12">
              <label for="student_id" class="form-label fw-semibold">Student ID</label>
              <input type="text" class="form-control" id="student_id" name="student_id" required
                     placeholder="e.g. STU-00123"
                     value="<?= isset($_POST['student_id']) ? htmlspecialchars($_POST['student_id']) : '' ?>">
            </div>
            <div class="col-md-6">
              <label for="password" class="form-label fw-semibold">Password</label>
              <input type="password" class="form-control" id="password" name="password" required
                     placeholder="Min. 8 characters">
            </div>
            <div class="col-md-6">
              <label for="confirm_password" class="form-label fw-semibold">Confirm Password</label>
              <input type="password" class="form-control" id="confirm_password" name="confirm_password" required
                     placeholder="Re-enter password">
            </div>
            <div class="col-12 mt-2">
              <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">Create Account</button>
            </div>
          </div>
        </form>
        <hr>
        <p class="text-center text-muted mb-0">
          Already have an account? <a href="login.php">Sign in here</a>
        </p>
      </div>
    </div>

  </div>
</div>

<footer class="text-center py-4 text-muted mt-5">
  <small>&copy; 2026 Online Course Registration System</small>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

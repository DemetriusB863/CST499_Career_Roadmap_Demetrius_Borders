<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Online Course Registration System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background: #f0f4f8; font-family: 'Segoe UI', sans-serif; }
    .hero {
      background: linear-gradient(135deg, #1a3c6e 0%, #2d6fbd 100%);
      color: white;
      padding: 100px 0 80px;
      text-align: center;
    }
    .hero h1 { font-size: 2.8rem; font-weight: 700; margin-bottom: 16px; }
    .hero p  { font-size: 1.2rem; opacity: 0.9; max-width: 560px; margin: 0 auto 32px; }
    .btn-hero-primary   { background: #fff; color: #1a3c6e; font-weight: 600; padding: 12px 32px; border-radius: 6px; text-decoration: none; margin-right: 12px; }
    .btn-hero-secondary { background: transparent; color: #fff; font-weight: 600; padding: 12px 32px; border-radius: 6px; border: 2px solid #fff; text-decoration: none; }
    .features { padding: 60px 0; }
    .feature-card { background: #fff; border-radius: 10px; padding: 32px 24px; text-align: center; box-shadow: 0 2px 12px rgba(0,0,0,.08); height: 100%; }
    .feature-icon { font-size: 2.4rem; margin-bottom: 16px; }
    nav { background: #1a3c6e; }
    nav a { color: #fff !important; }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg">
  <div class="container">
    <a class="navbar-brand fw-bold text-white" href="index.php">CourseReg</a>
    <div class="ms-auto">
      <a href="login.php" class="btn btn-outline-light me-2">Login</a>
      <a href="register.php" class="btn btn-light text-primary fw-bold">Register</a>
    </div>
  </div>
</nav>

<section class="hero">
  <div class="container">
    <h1>Online Course Registration System</h1>
    <p>Register for courses, manage your enrollment, and join waitlists — all in one secure platform.</p>
    <a href="register.php" class="btn-hero-primary">Get Started</a>
    <a href="login.php"    class="btn-hero-secondary">Sign In</a>
  </div>
</section>

<section class="features">
  <div class="container">
    <div class="row g-4">
      <div class="col-md-4">
        <div class="feature-card">
          <div class="feature-icon">📚</div>
          <h5 class="fw-bold">Browse Courses</h5>
          <p class="text-muted">View available courses by semester — Spring, Summer, and Fall.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="feature-card">
          <div class="feature-icon">✅</div>
          <h5 class="fw-bold">Easy Enrollment</h5>
          <p class="text-muted">Enroll in open courses or join a waitlist when capacity is full.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="feature-card">
          <div class="feature-icon">🔒</div>
          <h5 class="fw-bold">Secure Account</h5>
          <p class="text-muted">Your data is protected with hashed passwords and session authentication.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<footer class="text-center py-4 text-muted">
  <small>&copy; 2026 Online Course Registration System &mdash; CST499 Capstone Project</small>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

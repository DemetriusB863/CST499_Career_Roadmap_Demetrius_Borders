<?php
class DBConnection {
    private static $connection = null;

    public static function getConnection() {
        if (self::$connection === null) {
            $host     = "localhost";
            $username = "root";
            $password = "";          // XAMPP default: no password
            $database = "course_db";

            self::$connection = new mysqli($host, $username, $password, $database);

            if (self::$connection->connect_error) {
                die("Connection failed: " . self::$connection->connect_error);
            }
            self::$connection->set_charset("utf8");
        }
        return self::$connection;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login – Course Registration</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background: #f0f4f8; font-family: 'Segoe UI', sans-serif; min-height: 100vh; display: flex; flex-direction: column; }
    nav { background: #1a3c6e; }
    .card { border: none; border-radius: 12px; box-shadow: 0 4px 24px rgba(0,0,0,.10); }
    .card-header { background: linear-gradient(135deg, #1a3c6e, #2d6fbd); color: white; border-radius: 12px 12px 0 0 !important; text-align: center; padding: 24px; }
    .btn-primary { background: #1a3c6e; border: none; }
    .btn-primary:hover { background: #2d6fbd; }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg mb-5">
  <div class="container">
    <a class="navbar-brand fw-bold text-white" href="index.php">CourseReg</a>
    <div class="ms-auto">
      <a href="login.php"    class="btn btn-outline-light me-2">Login</a>
      <a href="register.php" class="btn btn-light text-primary fw-bold">Register</a>
    </div>
  </div>
</nav>

<div class="container d-flex justify-content-center flex-grow-1">
  <div class="col-md-5 col-lg-4">

    <?php
    session_start();
    $error = "";

    if (isset($_SESSION['success'])) {
        echo '<div class="alert alert-success">' . htmlspecialchars($_SESSION['success']) . '</div>';
        unset($_SESSION['success']);
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        require_once 'db_connection.php';
        $conn  = DBConnection::getConnection();
        $email = trim(htmlspecialchars($_POST['email']));
        $pass  = $_POST['password'];

        if (empty($email) || empty($pass)) {
            $error = "Please enter both email and password.";
        } else {
            $stmt = $conn->prepare("SELECT user_id, first_name, password_hash FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows === 1) {
                $stmt->bind_result($user_id, $first_name, $hash);
                $stmt->fetch();
                if (password_verify($pass, $hash)) {
                    $_SESSION['user_id']    = $user_id;
                    $_SESSION['first_name'] = $first_name;
                    header("Location: dashboard.php");
                    exit();
                } else {
                    $error = "Invalid email or password.";
                }
            } else {
                $error = "Invalid email or password.";
            }
            $stmt->close();
        }
    }
    ?>

    <?php if ($error): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card">
      <div class="card-header">
        <h4 class="mb-0 fw-bold">Sign In</h4>
        <small>Access your course registration account</small>
      </div>
      <div class="card-body p-4">
        <form method="POST" action="login.php">
          <div class="mb-3">
            <label for="email" class="form-label fw-semibold">Email Address</label>
            <input type="email" class="form-control" id="email" name="email" required placeholder="you@example.com">
          </div>
          <div class="mb-4">
            <label for="password" class="form-label fw-semibold">Password</label>
            <input type="password" class="form-control" id="password" name="password" required placeholder="••••••••">
          </div>
          <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">Sign In</button>
        </form>
        <hr>
        <p class="text-center text-muted mb-0">
          Don't have an account? <a href="register.php">Register here</a>
        </p>
      </div>
    </div>

  </div>
</div>

<footer class="text-center py-4 text-muted mt-5">
  <small>&copy; 2026 Online Course Registration System</small>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
